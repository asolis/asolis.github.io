Linux or windows (gcc)

>>  make
.....

Windows (VS2010)
>> double click raytracer.vcxproj


