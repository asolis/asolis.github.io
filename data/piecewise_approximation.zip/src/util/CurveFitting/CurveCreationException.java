// ==========================================================================
// $Id$
// ==========================================================================
// (C)opyright:
//
//   Andres Solis Montero
//   SITE, University of Ottawa
//   800 King Edward Ave.
//   Ottawa, On., K1N 6N5
//   Canada.
//   http://www.site.uottawa.ca
//
// Creator: asolis (Andres Solis Montero)
// Email:   asoli094@uottawa.ca
// ==========================================================================
// $Rev$
// $LastChangedBy$
// $LastChangedDate$
//
// ==========================================================================
package util.CurveFitting;

public class CurveCreationException extends Exception {

	public CurveCreationException() {
		// TODO Auto-generated constructor stub
	}

	public CurveCreationException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CurveCreationException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CurveCreationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
