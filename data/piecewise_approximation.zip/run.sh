#!/bin/sh
#/usr/java/jdk1.6.0_20/bin/java  -cp bin util.Graphics.CurveFitting
java  -cp bin util.Graphics.CurveFitting
