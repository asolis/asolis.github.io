#!/bin/sh
mkdir bin
#/usr/java/jdk1.6.0_20/bin/javac -d bin -sourcepath src -cp src src/util/Graphics/CurveFitting.java
javac -d bin -sourcepath src -cp src src/util/Graphics/CurveFitting.java
