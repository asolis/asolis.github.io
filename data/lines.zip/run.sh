#!/bin/bash

java -cp bin gui.LineSegment
